﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class configuraciones
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.layouTopScreen = New System.Windows.Forms.Panel()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.imgTopScreen = New System.Windows.Forms.PictureBox()
        Me.lblTopScreen = New System.Windows.Forms.Label()
        Me.layoutMC = New System.Windows.Forms.Panel()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.chbDisableEmp = New System.Windows.Forms.CheckBox()
        Me.btnCloseOpc = New System.Windows.Forms.Panel()
        Me.imgBtnCloseOpc = New System.Windows.Forms.PictureBox()
        Me.lblBtnCloseOpc = New System.Windows.Forms.Label()
        Me.styleBtnCloseOpc = New System.Windows.Forms.Panel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.btnTheme = New System.Windows.Forms.Panel()
        Me.imgBtnTheme = New System.Windows.Forms.PictureBox()
        Me.lblBtnTheme = New System.Windows.Forms.Label()
        Me.styleBtnTheme = New System.Windows.Forms.Panel()
        Me.btnServers = New System.Windows.Forms.Panel()
        Me.imgBtnServers = New System.Windows.Forms.PictureBox()
        Me.lblBtnServers = New System.Windows.Forms.Label()
        Me.styleBtnServers = New System.Windows.Forms.Panel()
        Me.btnGeneral = New System.Windows.Forms.Panel()
        Me.imgBtnGeneral = New System.Windows.Forms.PictureBox()
        Me.lblBtnGeneral = New System.Windows.Forms.Label()
        Me.styleBtnGeneral = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.layoutServers = New System.Windows.Forms.Panel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.TBoxPort = New System.Windows.Forms.TextBox()
        Me.styleTBoxPort = New System.Windows.Forms.Panel()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.TBoxPass = New System.Windows.Forms.TextBox()
        Me.styleTBoxPass = New System.Windows.Forms.Panel()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.TBoxUser = New System.Windows.Forms.TextBox()
        Me.styleTBoxUser = New System.Windows.Forms.Panel()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.TBoxDB = New System.Windows.Forms.TextBox()
        Me.styleTBoxDB = New System.Windows.Forms.Panel()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.TBoxIP = New System.Windows.Forms.TextBox()
        Me.styleTBoxIP = New System.Windows.Forms.Panel()
        Me.btnApply = New System.Windows.Forms.Panel()
        Me.imgBtnApply = New System.Windows.Forms.PictureBox()
        Me.lblBtnApply = New System.Windows.Forms.Label()
        Me.styleBtnApply = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.rbRemoteServer = New System.Windows.Forms.RadioButton()
        Me.rbLocalServer = New System.Windows.Forms.RadioButton()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.layoutGeneral = New System.Windows.Forms.Panel()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.TBoxAcessPass = New System.Windows.Forms.TextBox()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.btnApplyS = New System.Windows.Forms.Panel()
        Me.imgBtnApplyS = New System.Windows.Forms.PictureBox()
        Me.lblBtnApplyS = New System.Windows.Forms.Label()
        Me.styleBtnApplyS = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.layoutThemes = New System.Windows.Forms.Panel()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.HScrollBar3 = New System.Windows.Forms.HScrollBar()
        Me.HScrollBar2 = New System.Windows.Forms.HScrollBar()
        Me.HScrollBar1 = New System.Windows.Forms.HScrollBar()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.layouTopScreen.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgTopScreen, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.layoutMC.SuspendLayout()
        Me.btnCloseOpc.SuspendLayout()
        CType(Me.imgBtnCloseOpc, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.btnTheme.SuspendLayout()
        CType(Me.imgBtnTheme, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.btnServers.SuspendLayout()
        CType(Me.imgBtnServers, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.btnGeneral.SuspendLayout()
        CType(Me.imgBtnGeneral, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.layoutServers.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.btnApply.SuspendLayout()
        CType(Me.imgBtnApply, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.layoutGeneral.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.btnApplyS.SuspendLayout()
        CType(Me.imgBtnApplyS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.layoutThemes.SuspendLayout()
        Me.Panel15.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel14.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel8.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'layouTopScreen
        '
        Me.layouTopScreen.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.layouTopScreen.Controls.Add(Me.PictureBox6)
        Me.layouTopScreen.Controls.Add(Me.Panel3)
        Me.layouTopScreen.Controls.Add(Me.Panel2)
        Me.layouTopScreen.Controls.Add(Me.Panel1)
        Me.layouTopScreen.Controls.Add(Me.imgTopScreen)
        Me.layouTopScreen.Controls.Add(Me.lblTopScreen)
        Me.layouTopScreen.Dock = System.Windows.Forms.DockStyle.Top
        Me.layouTopScreen.Location = New System.Drawing.Point(0, 0)
        Me.layouTopScreen.Name = "layouTopScreen"
        Me.layouTopScreen.Size = New System.Drawing.Size(980, 30)
        Me.layouTopScreen.TabIndex = 0
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.ForUTU.My.Resources.Resources.TCEIcon
        Me.PictureBox6.Location = New System.Drawing.Point(930, 2)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(47, 25)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox6.TabIndex = 11
        Me.PictureBox6.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(1, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(978, 1)
        Me.Panel3.TabIndex = 10
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(979, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1, 30)
        Me.Panel2.TabIndex = 9
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1, 30)
        Me.Panel1.TabIndex = 8
        '
        'imgTopScreen
        '
        Me.imgTopScreen.Image = Global.ForUTU.My.Resources.Resources.baseline_keyboard_backspace_black_18dp
        Me.imgTopScreen.Location = New System.Drawing.Point(3, 2)
        Me.imgTopScreen.Name = "imgTopScreen"
        Me.imgTopScreen.Size = New System.Drawing.Size(31, 25)
        Me.imgTopScreen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgTopScreen.TabIndex = 4
        Me.imgTopScreen.TabStop = False
        '
        'lblTopScreen
        '
        Me.lblTopScreen.AutoSize = True
        Me.lblTopScreen.Font = New System.Drawing.Font("Arial", 11.0!)
        Me.lblTopScreen.ForeColor = System.Drawing.Color.Black
        Me.lblTopScreen.Location = New System.Drawing.Point(34, 6)
        Me.lblTopScreen.Name = "lblTopScreen"
        Me.lblTopScreen.Size = New System.Drawing.Size(114, 17)
        Me.lblTopScreen.TabIndex = 3
        Me.lblTopScreen.Text = "Configuraciones"
        '
        'layoutMC
        '
        Me.layoutMC.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.layoutMC.Controls.Add(Me.Label24)
        Me.layoutMC.Controls.Add(Me.chbDisableEmp)
        Me.layoutMC.Controls.Add(Me.btnCloseOpc)
        Me.layoutMC.Controls.Add(Me.Panel12)
        Me.layoutMC.Controls.Add(Me.Panel11)
        Me.layoutMC.Controls.Add(Me.btnTheme)
        Me.layoutMC.Controls.Add(Me.btnServers)
        Me.layoutMC.Controls.Add(Me.btnGeneral)
        Me.layoutMC.Dock = System.Windows.Forms.DockStyle.Left
        Me.layoutMC.Location = New System.Drawing.Point(0, 30)
        Me.layoutMC.Name = "layoutMC"
        Me.layoutMC.Size = New System.Drawing.Size(166, 492)
        Me.layoutMC.TabIndex = 1
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.Label24.Location = New System.Drawing.Point(24, 145)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(142, 13)
        Me.Label24.TabIndex = 23
        Me.Label24.Text = "Desactivar mensaje de inicio"
        '
        'chbDisableEmp
        '
        Me.chbDisableEmp.AutoSize = True
        Me.chbDisableEmp.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.4!)
        Me.chbDisableEmp.Location = New System.Drawing.Point(11, 145)
        Me.chbDisableEmp.Name = "chbDisableEmp"
        Me.chbDisableEmp.Size = New System.Drawing.Size(15, 14)
        Me.chbDisableEmp.TabIndex = 8
        Me.chbDisableEmp.UseVisualStyleBackColor = True
        '
        'btnCloseOpc
        '
        Me.btnCloseOpc.Controls.Add(Me.imgBtnCloseOpc)
        Me.btnCloseOpc.Controls.Add(Me.lblBtnCloseOpc)
        Me.btnCloseOpc.Controls.Add(Me.styleBtnCloseOpc)
        Me.btnCloseOpc.Location = New System.Drawing.Point(12, 450)
        Me.btnCloseOpc.Name = "btnCloseOpc"
        Me.btnCloseOpc.Size = New System.Drawing.Size(136, 30)
        Me.btnCloseOpc.TabIndex = 4
        Me.btnCloseOpc.Visible = False
        '
        'imgBtnCloseOpc
        '
        Me.imgBtnCloseOpc.Image = Global.ForUTU.My.Resources.Resources.baseline_clear_black_18dp
        Me.imgBtnCloseOpc.Location = New System.Drawing.Point(15, 3)
        Me.imgBtnCloseOpc.Name = "imgBtnCloseOpc"
        Me.imgBtnCloseOpc.Size = New System.Drawing.Size(25, 25)
        Me.imgBtnCloseOpc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgBtnCloseOpc.TabIndex = 2
        Me.imgBtnCloseOpc.TabStop = False
        '
        'lblBtnCloseOpc
        '
        Me.lblBtnCloseOpc.AutoSize = True
        Me.lblBtnCloseOpc.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.lblBtnCloseOpc.Location = New System.Drawing.Point(46, 7)
        Me.lblBtnCloseOpc.Name = "lblBtnCloseOpc"
        Me.lblBtnCloseOpc.Size = New System.Drawing.Size(49, 16)
        Me.lblBtnCloseOpc.TabIndex = 2
        Me.lblBtnCloseOpc.Text = "Cerrar"
        '
        'styleBtnCloseOpc
        '
        Me.styleBtnCloseOpc.BackColor = System.Drawing.Color.FromArgb(CType(CType(72, Byte), Integer), CType(CType(72, Byte), Integer), CType(CType(72, Byte), Integer))
        Me.styleBtnCloseOpc.Dock = System.Windows.Forms.DockStyle.Left
        Me.styleBtnCloseOpc.Location = New System.Drawing.Point(0, 0)
        Me.styleBtnCloseOpc.Name = "styleBtnCloseOpc"
        Me.styleBtnCloseOpc.Size = New System.Drawing.Size(5, 30)
        Me.styleBtnCloseOpc.TabIndex = 3
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Panel12.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel12.Location = New System.Drawing.Point(0, 0)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(1, 491)
        Me.Panel12.TabIndex = 7
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel11.Location = New System.Drawing.Point(0, 491)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(166, 1)
        Me.Panel11.TabIndex = 6
        '
        'btnTheme
        '
        Me.btnTheme.Controls.Add(Me.imgBtnTheme)
        Me.btnTheme.Controls.Add(Me.lblBtnTheme)
        Me.btnTheme.Controls.Add(Me.styleBtnTheme)
        Me.btnTheme.Location = New System.Drawing.Point(12, 103)
        Me.btnTheme.Name = "btnTheme"
        Me.btnTheme.Size = New System.Drawing.Size(136, 35)
        Me.btnTheme.TabIndex = 5
        Me.btnTheme.Visible = False
        '
        'imgBtnTheme
        '
        Me.imgBtnTheme.Image = Global.ForUTU.My.Resources.Resources.baseline_color_lens_black_18dp
        Me.imgBtnTheme.Location = New System.Drawing.Point(15, 5)
        Me.imgBtnTheme.Name = "imgBtnTheme"
        Me.imgBtnTheme.Size = New System.Drawing.Size(25, 25)
        Me.imgBtnTheme.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgBtnTheme.TabIndex = 2
        Me.imgBtnTheme.TabStop = False
        '
        'lblBtnTheme
        '
        Me.lblBtnTheme.AutoSize = True
        Me.lblBtnTheme.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.lblBtnTheme.Location = New System.Drawing.Point(46, 10)
        Me.lblBtnTheme.Name = "lblBtnTheme"
        Me.lblBtnTheme.Size = New System.Drawing.Size(49, 16)
        Me.lblBtnTheme.TabIndex = 2
        Me.lblBtnTheme.Text = "Temas"
        '
        'styleBtnTheme
        '
        Me.styleBtnTheme.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.styleBtnTheme.Dock = System.Windows.Forms.DockStyle.Left
        Me.styleBtnTheme.Location = New System.Drawing.Point(0, 0)
        Me.styleBtnTheme.Name = "styleBtnTheme"
        Me.styleBtnTheme.Size = New System.Drawing.Size(5, 35)
        Me.styleBtnTheme.TabIndex = 3
        '
        'btnServers
        '
        Me.btnServers.Controls.Add(Me.imgBtnServers)
        Me.btnServers.Controls.Add(Me.lblBtnServers)
        Me.btnServers.Controls.Add(Me.styleBtnServers)
        Me.btnServers.Location = New System.Drawing.Point(12, 62)
        Me.btnServers.Name = "btnServers"
        Me.btnServers.Size = New System.Drawing.Size(136, 35)
        Me.btnServers.TabIndex = 4
        '
        'imgBtnServers
        '
        Me.imgBtnServers.Image = Global.ForUTU.My.Resources.Resources.if_server_298866
        Me.imgBtnServers.Location = New System.Drawing.Point(15, 5)
        Me.imgBtnServers.Name = "imgBtnServers"
        Me.imgBtnServers.Size = New System.Drawing.Size(25, 25)
        Me.imgBtnServers.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgBtnServers.TabIndex = 2
        Me.imgBtnServers.TabStop = False
        '
        'lblBtnServers
        '
        Me.lblBtnServers.AutoSize = True
        Me.lblBtnServers.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.lblBtnServers.Location = New System.Drawing.Point(46, 10)
        Me.lblBtnServers.Name = "lblBtnServers"
        Me.lblBtnServers.Size = New System.Drawing.Size(76, 16)
        Me.lblBtnServers.TabIndex = 2
        Me.lblBtnServers.Text = "Servidores"
        '
        'styleBtnServers
        '
        Me.styleBtnServers.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.styleBtnServers.Dock = System.Windows.Forms.DockStyle.Left
        Me.styleBtnServers.Location = New System.Drawing.Point(0, 0)
        Me.styleBtnServers.Name = "styleBtnServers"
        Me.styleBtnServers.Size = New System.Drawing.Size(5, 35)
        Me.styleBtnServers.TabIndex = 3
        '
        'btnGeneral
        '
        Me.btnGeneral.Controls.Add(Me.imgBtnGeneral)
        Me.btnGeneral.Controls.Add(Me.lblBtnGeneral)
        Me.btnGeneral.Controls.Add(Me.styleBtnGeneral)
        Me.btnGeneral.Location = New System.Drawing.Point(12, 21)
        Me.btnGeneral.Name = "btnGeneral"
        Me.btnGeneral.Size = New System.Drawing.Size(136, 35)
        Me.btnGeneral.TabIndex = 2
        '
        'imgBtnGeneral
        '
        Me.imgBtnGeneral.Image = Global.ForUTU.My.Resources.Resources.baseline_security_black_18dp
        Me.imgBtnGeneral.Location = New System.Drawing.Point(15, 5)
        Me.imgBtnGeneral.Name = "imgBtnGeneral"
        Me.imgBtnGeneral.Size = New System.Drawing.Size(25, 25)
        Me.imgBtnGeneral.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgBtnGeneral.TabIndex = 2
        Me.imgBtnGeneral.TabStop = False
        '
        'lblBtnGeneral
        '
        Me.lblBtnGeneral.AutoSize = True
        Me.lblBtnGeneral.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.lblBtnGeneral.Location = New System.Drawing.Point(46, 9)
        Me.lblBtnGeneral.Name = "lblBtnGeneral"
        Me.lblBtnGeneral.Size = New System.Drawing.Size(73, 16)
        Me.lblBtnGeneral.TabIndex = 2
        Me.lblBtnGeneral.Text = "Seguridad"
        '
        'styleBtnGeneral
        '
        Me.styleBtnGeneral.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(188, Byte), Integer))
        Me.styleBtnGeneral.Dock = System.Windows.Forms.DockStyle.Left
        Me.styleBtnGeneral.Location = New System.Drawing.Point(0, 0)
        Me.styleBtnGeneral.Name = "styleBtnGeneral"
        Me.styleBtnGeneral.Size = New System.Drawing.Size(5, 35)
        Me.styleBtnGeneral.TabIndex = 3
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel9.Location = New System.Drawing.Point(166, 521)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(814, 1)
        Me.Panel9.TabIndex = 2
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel10.Location = New System.Drawing.Point(979, 30)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(1, 491)
        Me.Panel10.TabIndex = 3
        '
        'layoutServers
        '
        Me.layoutServers.Controls.Add(Me.Panel17)
        Me.layoutServers.Controls.Add(Me.Panel22)
        Me.layoutServers.Controls.Add(Me.Panel20)
        Me.layoutServers.Controls.Add(Me.Panel18)
        Me.layoutServers.Controls.Add(Me.Panel16)
        Me.layoutServers.Controls.Add(Me.btnApply)
        Me.layoutServers.Controls.Add(Me.Label1)
        Me.layoutServers.Controls.Add(Me.rbRemoteServer)
        Me.layoutServers.Controls.Add(Me.rbLocalServer)
        Me.layoutServers.Controls.Add(Me.Label7)
        Me.layoutServers.Controls.Add(Me.Label6)
        Me.layoutServers.Controls.Add(Me.Label5)
        Me.layoutServers.Controls.Add(Me.Label4)
        Me.layoutServers.Controls.Add(Me.Label3)
        Me.layoutServers.Dock = System.Windows.Forms.DockStyle.Fill
        Me.layoutServers.Location = New System.Drawing.Point(166, 30)
        Me.layoutServers.Name = "layoutServers"
        Me.layoutServers.Size = New System.Drawing.Size(813, 491)
        Me.layoutServers.TabIndex = 4
        Me.layoutServers.Visible = False
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.TBoxPort)
        Me.Panel17.Controls.Add(Me.styleTBoxPort)
        Me.Panel17.Location = New System.Drawing.Point(373, 48)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(53, 23)
        Me.Panel17.TabIndex = 24
        '
        'TBoxPort
        '
        Me.TBoxPort.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TBoxPort.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TBoxPort.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TBoxPort.Location = New System.Drawing.Point(3, 7)
        Me.TBoxPort.Name = "TBoxPort"
        Me.TBoxPort.Size = New System.Drawing.Size(47, 14)
        Me.TBoxPort.TabIndex = 5
        '
        'styleTBoxPort
        '
        Me.styleTBoxPort.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.styleTBoxPort.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.styleTBoxPort.Location = New System.Drawing.Point(0, 22)
        Me.styleTBoxPort.Name = "styleTBoxPort"
        Me.styleTBoxPort.Size = New System.Drawing.Size(53, 1)
        Me.styleTBoxPort.TabIndex = 4
        '
        'Panel22
        '
        Me.Panel22.Controls.Add(Me.TBoxPass)
        Me.Panel22.Controls.Add(Me.styleTBoxPass)
        Me.Panel22.Location = New System.Drawing.Point(136, 135)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(167, 23)
        Me.Panel22.TabIndex = 23
        '
        'TBoxPass
        '
        Me.TBoxPass.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TBoxPass.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TBoxPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TBoxPass.Location = New System.Drawing.Point(3, 7)
        Me.TBoxPass.Name = "TBoxPass"
        Me.TBoxPass.Size = New System.Drawing.Size(161, 14)
        Me.TBoxPass.TabIndex = 5
        '
        'styleTBoxPass
        '
        Me.styleTBoxPass.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.styleTBoxPass.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.styleTBoxPass.Location = New System.Drawing.Point(0, 22)
        Me.styleTBoxPass.Name = "styleTBoxPass"
        Me.styleTBoxPass.Size = New System.Drawing.Size(167, 1)
        Me.styleTBoxPass.TabIndex = 4
        '
        'Panel20
        '
        Me.Panel20.Controls.Add(Me.TBoxUser)
        Me.Panel20.Controls.Add(Me.styleTBoxUser)
        Me.Panel20.Location = New System.Drawing.Point(136, 106)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(167, 23)
        Me.Panel20.TabIndex = 22
        '
        'TBoxUser
        '
        Me.TBoxUser.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TBoxUser.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TBoxUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TBoxUser.Location = New System.Drawing.Point(3, 7)
        Me.TBoxUser.Name = "TBoxUser"
        Me.TBoxUser.Size = New System.Drawing.Size(161, 14)
        Me.TBoxUser.TabIndex = 5
        '
        'styleTBoxUser
        '
        Me.styleTBoxUser.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.styleTBoxUser.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.styleTBoxUser.Location = New System.Drawing.Point(0, 22)
        Me.styleTBoxUser.Name = "styleTBoxUser"
        Me.styleTBoxUser.Size = New System.Drawing.Size(167, 1)
        Me.styleTBoxUser.TabIndex = 4
        '
        'Panel18
        '
        Me.Panel18.Controls.Add(Me.TBoxDB)
        Me.Panel18.Controls.Add(Me.styleTBoxDB)
        Me.Panel18.Location = New System.Drawing.Point(136, 77)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(167, 23)
        Me.Panel18.TabIndex = 21
        '
        'TBoxDB
        '
        Me.TBoxDB.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TBoxDB.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TBoxDB.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TBoxDB.Location = New System.Drawing.Point(3, 7)
        Me.TBoxDB.Name = "TBoxDB"
        Me.TBoxDB.Size = New System.Drawing.Size(161, 14)
        Me.TBoxDB.TabIndex = 5
        '
        'styleTBoxDB
        '
        Me.styleTBoxDB.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.styleTBoxDB.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.styleTBoxDB.Location = New System.Drawing.Point(0, 22)
        Me.styleTBoxDB.Name = "styleTBoxDB"
        Me.styleTBoxDB.Size = New System.Drawing.Size(167, 1)
        Me.styleTBoxDB.TabIndex = 4
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.TBoxIP)
        Me.Panel16.Controls.Add(Me.styleTBoxIP)
        Me.Panel16.Location = New System.Drawing.Point(136, 48)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(167, 23)
        Me.Panel16.TabIndex = 20
        '
        'TBoxIP
        '
        Me.TBoxIP.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TBoxIP.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TBoxIP.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TBoxIP.Location = New System.Drawing.Point(3, 7)
        Me.TBoxIP.Name = "TBoxIP"
        Me.TBoxIP.Size = New System.Drawing.Size(161, 14)
        Me.TBoxIP.TabIndex = 5
        '
        'styleTBoxIP
        '
        Me.styleTBoxIP.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.styleTBoxIP.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.styleTBoxIP.Location = New System.Drawing.Point(0, 22)
        Me.styleTBoxIP.Name = "styleTBoxIP"
        Me.styleTBoxIP.Size = New System.Drawing.Size(167, 1)
        Me.styleTBoxIP.TabIndex = 4
        '
        'btnApply
        '
        Me.btnApply.Controls.Add(Me.imgBtnApply)
        Me.btnApply.Controls.Add(Me.lblBtnApply)
        Me.btnApply.Controls.Add(Me.styleBtnApply)
        Me.btnApply.Location = New System.Drawing.Point(684, 445)
        Me.btnApply.Name = "btnApply"
        Me.btnApply.Size = New System.Drawing.Size(109, 35)
        Me.btnApply.TabIndex = 4
        '
        'imgBtnApply
        '
        Me.imgBtnApply.Image = Global.ForUTU.My.Resources.Resources.baseline_check_black_18dp
        Me.imgBtnApply.Location = New System.Drawing.Point(11, 5)
        Me.imgBtnApply.Name = "imgBtnApply"
        Me.imgBtnApply.Size = New System.Drawing.Size(25, 25)
        Me.imgBtnApply.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgBtnApply.TabIndex = 2
        Me.imgBtnApply.TabStop = False
        '
        'lblBtnApply
        '
        Me.lblBtnApply.AutoSize = True
        Me.lblBtnApply.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.lblBtnApply.Location = New System.Drawing.Point(46, 9)
        Me.lblBtnApply.Name = "lblBtnApply"
        Me.lblBtnApply.Size = New System.Drawing.Size(51, 16)
        Me.lblBtnApply.TabIndex = 2
        Me.lblBtnApply.Text = "Aplicar"
        '
        'styleBtnApply
        '
        Me.styleBtnApply.BackColor = System.Drawing.Color.Green
        Me.styleBtnApply.Dock = System.Windows.Forms.DockStyle.Left
        Me.styleBtnApply.Location = New System.Drawing.Point(0, 0)
        Me.styleBtnApply.Name = "styleBtnApply"
        Me.styleBtnApply.Size = New System.Drawing.Size(5, 35)
        Me.styleBtnApply.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 15.0!)
        Me.Label1.Location = New System.Drawing.Point(278, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(257, 23)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Configuración de Servidores"
        '
        'rbRemoteServer
        '
        Me.rbRemoteServer.AutoSize = True
        Me.rbRemoteServer.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.rbRemoteServer.Location = New System.Drawing.Point(690, 26)
        Me.rbRemoteServer.Name = "rbRemoteServer"
        Me.rbRemoteServer.Size = New System.Drawing.Size(112, 19)
        Me.rbRemoteServer.TabIndex = 18
        Me.rbRemoteServer.TabStop = True
        Me.rbRemoteServer.Text = "Servidor remoto"
        Me.rbRemoteServer.UseVisualStyleBackColor = True
        '
        'rbLocalServer
        '
        Me.rbLocalServer.AutoSize = True
        Me.rbLocalServer.Checked = True
        Me.rbLocalServer.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.rbLocalServer.Location = New System.Drawing.Point(690, 5)
        Me.rbLocalServer.Name = "rbLocalServer"
        Me.rbLocalServer.Size = New System.Drawing.Size(99, 19)
        Me.rbLocalServer.TabIndex = 17
        Me.rbLocalServer.TabStop = True
        Me.rbLocalServer.Text = "Servidor local"
        Me.rbLocalServer.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.Label7.Location = New System.Drawing.Point(16, 79)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(114, 18)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Base de datos:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.Label6.Location = New System.Drawing.Point(37, 137)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 18)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Contraseña:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.Label5.Location = New System.Drawing.Point(64, 108)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 18)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Usuario:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.Label4.Location = New System.Drawing.Point(309, 50)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 18)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Puerto:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.Label3.Location = New System.Drawing.Point(33, 50)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 18)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Dirección IP:"
        '
        'layoutGeneral
        '
        Me.layoutGeneral.Controls.Add(Me.Panel19)
        Me.layoutGeneral.Controls.Add(Me.btnApplyS)
        Me.layoutGeneral.Controls.Add(Me.Label8)
        Me.layoutGeneral.Controls.Add(Me.Label2)
        Me.layoutGeneral.Dock = System.Windows.Forms.DockStyle.Fill
        Me.layoutGeneral.Location = New System.Drawing.Point(166, 30)
        Me.layoutGeneral.Name = "layoutGeneral"
        Me.layoutGeneral.Size = New System.Drawing.Size(813, 491)
        Me.layoutGeneral.TabIndex = 21
        Me.layoutGeneral.Visible = False
        '
        'Panel19
        '
        Me.Panel19.Controls.Add(Me.TBoxAcessPass)
        Me.Panel19.Controls.Add(Me.Panel21)
        Me.Panel19.Location = New System.Drawing.Point(123, 36)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(167, 23)
        Me.Panel19.TabIndex = 24
        '
        'TBoxAcessPass
        '
        Me.TBoxAcessPass.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TBoxAcessPass.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TBoxAcessPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TBoxAcessPass.Location = New System.Drawing.Point(3, 7)
        Me.TBoxAcessPass.Name = "TBoxAcessPass"
        Me.TBoxAcessPass.Size = New System.Drawing.Size(161, 14)
        Me.TBoxAcessPass.TabIndex = 5
        '
        'Panel21
        '
        Me.Panel21.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Panel21.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel21.Location = New System.Drawing.Point(0, 22)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(167, 1)
        Me.Panel21.TabIndex = 4
        '
        'btnApplyS
        '
        Me.btnApplyS.Controls.Add(Me.imgBtnApplyS)
        Me.btnApplyS.Controls.Add(Me.lblBtnApplyS)
        Me.btnApplyS.Controls.Add(Me.styleBtnApplyS)
        Me.btnApplyS.Location = New System.Drawing.Point(684, 445)
        Me.btnApplyS.Name = "btnApplyS"
        Me.btnApplyS.Size = New System.Drawing.Size(109, 35)
        Me.btnApplyS.TabIndex = 5
        '
        'imgBtnApplyS
        '
        Me.imgBtnApplyS.Image = Global.ForUTU.My.Resources.Resources.baseline_check_black_18dp
        Me.imgBtnApplyS.Location = New System.Drawing.Point(11, 5)
        Me.imgBtnApplyS.Name = "imgBtnApplyS"
        Me.imgBtnApplyS.Size = New System.Drawing.Size(25, 25)
        Me.imgBtnApplyS.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgBtnApplyS.TabIndex = 2
        Me.imgBtnApplyS.TabStop = False
        '
        'lblBtnApplyS
        '
        Me.lblBtnApplyS.AutoSize = True
        Me.lblBtnApplyS.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.lblBtnApplyS.Location = New System.Drawing.Point(46, 9)
        Me.lblBtnApplyS.Name = "lblBtnApplyS"
        Me.lblBtnApplyS.Size = New System.Drawing.Size(51, 16)
        Me.lblBtnApplyS.TabIndex = 2
        Me.lblBtnApplyS.Text = "Aplicar"
        '
        'styleBtnApplyS
        '
        Me.styleBtnApplyS.BackColor = System.Drawing.Color.Green
        Me.styleBtnApplyS.Dock = System.Windows.Forms.DockStyle.Left
        Me.styleBtnApplyS.Location = New System.Drawing.Point(0, 0)
        Me.styleBtnApplyS.Name = "styleBtnApplyS"
        Me.styleBtnApplyS.Size = New System.Drawing.Size(5, 35)
        Me.styleBtnApplyS.TabIndex = 3
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 15.0!)
        Me.Label8.Location = New System.Drawing.Point(278, 5)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(252, 23)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Configuración de Seguridad"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.Label2.Location = New System.Drawing.Point(16, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 15)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Clave de acceso:"
        '
        'layoutThemes
        '
        Me.layoutThemes.Controls.Add(Me.Panel15)
        Me.layoutThemes.Controls.Add(Me.Panel14)
        Me.layoutThemes.Controls.Add(Me.PictureBox4)
        Me.layoutThemes.Controls.Add(Me.PictureBox3)
        Me.layoutThemes.Controls.Add(Me.Label16)
        Me.layoutThemes.Controls.Add(Me.Label15)
        Me.layoutThemes.Controls.Add(Me.Label14)
        Me.layoutThemes.Controls.Add(Me.Label13)
        Me.layoutThemes.Controls.Add(Me.Label12)
        Me.layoutThemes.Controls.Add(Me.Label11)
        Me.layoutThemes.Controls.Add(Me.GroupBox2)
        Me.layoutThemes.Controls.Add(Me.Label10)
        Me.layoutThemes.Controls.Add(Me.Label9)
        Me.layoutThemes.Dock = System.Windows.Forms.DockStyle.Fill
        Me.layoutThemes.Location = New System.Drawing.Point(166, 30)
        Me.layoutThemes.Name = "layoutThemes"
        Me.layoutThemes.Size = New System.Drawing.Size(813, 491)
        Me.layoutThemes.TabIndex = 22
        Me.layoutThemes.Visible = False
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel15.Controls.Add(Me.PictureBox2)
        Me.Panel15.Location = New System.Drawing.Point(442, 26)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(343, 203)
        Me.Panel15.TabIndex = 15
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.ForUTU.My.Resources.Resources.thecodeeyetheme
        Me.PictureBox2.Location = New System.Drawing.Point(1, 1)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(341, 201)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'Panel14
        '
        Me.Panel14.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Panel14.Controls.Add(Me.PictureBox1)
        Me.Panel14.Location = New System.Drawing.Point(49, 26)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(343, 203)
        Me.Panel14.TabIndex = 14
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ForUTU.My.Resources.Resources.windowstheme
        Me.PictureBox1.Location = New System.Drawing.Point(1, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(341, 201)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Location = New System.Drawing.Point(108, 310)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(195, 39)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 13
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Location = New System.Drawing.Point(108, 262)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(195, 39)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 12
        Me.PictureBox3.TabStop = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label16.Location = New System.Drawing.Point(53, 426)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(50, 16)
        Me.Label16.TabIndex = 11
        Me.Label16.Text = "Borde:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label15.Location = New System.Drawing.Point(57, 401)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(46, 16)
        Me.Label15.TabIndex = 10
        Me.Label15.Text = "Color:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label14.Location = New System.Drawing.Point(46, 376)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(57, 16)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "Fuente:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label13.Location = New System.Drawing.Point(8, 322)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(95, 16)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "Caja de texto:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label12.Location = New System.Drawing.Point(54, 274)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(49, 16)
        Me.Label12.TabIndex = 7
        Me.Label12.Text = "Botón:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.Label11.Location = New System.Drawing.Point(157, 234)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(91, 18)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "Vista previa"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.PictureBox5)
        Me.GroupBox2.Controls.Add(Me.Panel8)
        Me.GroupBox2.Controls.Add(Me.Panel6)
        Me.GroupBox2.Controls.Add(Me.Panel4)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.HScrollBar3)
        Me.GroupBox2.Controls.Add(Me.HScrollBar2)
        Me.GroupBox2.Controls.Add(Me.HScrollBar1)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Location = New System.Drawing.Point(443, 240)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(338, 237)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Colores de los estilos"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.Label23.Location = New System.Drawing.Point(153, 122)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(46, 18)
        Me.Label23.TabIndex = 14
        Me.Label23.Text = "Color"
        '
        'PictureBox5
        '
        Me.PictureBox5.Location = New System.Drawing.Point(9, 152)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(323, 65)
        Me.PictureBox5.TabIndex = 14
        Me.PictureBox5.TabStop = False
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.TextBox9)
        Me.Panel8.Controls.Add(Me.Panel13)
        Me.Panel8.Location = New System.Drawing.Point(300, 80)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(35, 25)
        Me.Panel8.TabIndex = 23
        '
        'TextBox9
        '
        Me.TextBox9.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox9.Location = New System.Drawing.Point(3, 6)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(31, 13)
        Me.TextBox9.TabIndex = 5
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Panel13.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel13.Location = New System.Drawing.Point(0, 24)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(35, 1)
        Me.Panel13.TabIndex = 4
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.TextBox8)
        Me.Panel6.Controls.Add(Me.Panel7)
        Me.Panel6.Location = New System.Drawing.Point(300, 53)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(35, 25)
        Me.Panel6.TabIndex = 15
        '
        'TextBox8
        '
        Me.TextBox8.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox8.Location = New System.Drawing.Point(3, 6)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(31, 13)
        Me.TextBox8.TabIndex = 5
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel7.Location = New System.Drawing.Point(0, 24)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(35, 1)
        Me.Panel7.TabIndex = 4
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.TextBox7)
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Location = New System.Drawing.Point(300, 26)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(35, 25)
        Me.Panel4.TabIndex = 14
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox7.Location = New System.Drawing.Point(3, 6)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(31, 13)
        Me.TextBox7.TabIndex = 5
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(154, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel5.Location = New System.Drawing.Point(0, 24)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(35, 1)
        Me.Panel5.TabIndex = 4
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label22.Location = New System.Drawing.Point(284, 85)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(12, 16)
        Me.Label22.TabIndex = 22
        Me.Label22.Text = ":"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label21.Location = New System.Drawing.Point(284, 58)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(12, 16)
        Me.Label21.TabIndex = 21
        Me.Label21.Text = ":"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label20.Location = New System.Drawing.Point(284, 30)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(12, 16)
        Me.Label20.TabIndex = 20
        Me.Label20.Text = ":"
        '
        'HScrollBar3
        '
        Me.HScrollBar3.Location = New System.Drawing.Point(32, 85)
        Me.HScrollBar3.Maximum = 255
        Me.HScrollBar3.Name = "HScrollBar3"
        Me.HScrollBar3.Size = New System.Drawing.Size(245, 17)
        Me.HScrollBar3.TabIndex = 19
        '
        'HScrollBar2
        '
        Me.HScrollBar2.Location = New System.Drawing.Point(32, 58)
        Me.HScrollBar2.Maximum = 255
        Me.HScrollBar2.Name = "HScrollBar2"
        Me.HScrollBar2.Size = New System.Drawing.Size(245, 17)
        Me.HScrollBar2.TabIndex = 18
        '
        'HScrollBar1
        '
        Me.HScrollBar1.Location = New System.Drawing.Point(32, 29)
        Me.HScrollBar1.Maximum = 255
        Me.HScrollBar1.Name = "HScrollBar1"
        Me.HScrollBar1.Size = New System.Drawing.Size(245, 17)
        Me.HScrollBar1.TabIndex = 17
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label19.Location = New System.Drawing.Point(6, 58)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(23, 16)
        Me.Label19.TabIndex = 16
        Me.Label19.Text = "G:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label18.Location = New System.Drawing.Point(8, 86)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(21, 16)
        Me.Label18.TabIndex = 15
        Me.Label18.Text = "B:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label17.Location = New System.Drawing.Point(7, 29)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(22, 16)
        Me.Label17.TabIndex = 14
        Me.Label17.Text = "R:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label10.Location = New System.Drawing.Point(543, 6)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(129, 16)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "Tema TheCodeEye"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.Label9.Location = New System.Drawing.Point(169, 7)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(102, 16)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Tema Windows"
        '
        'configuraciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(980, 522)
        Me.Controls.Add(Me.layoutServers)
        Me.Controls.Add(Me.layoutThemes)
        Me.Controls.Add(Me.layoutGeneral)
        Me.Controls.Add(Me.Panel10)
        Me.Controls.Add(Me.Panel9)
        Me.Controls.Add(Me.layoutMC)
        Me.Controls.Add(Me.layouTopScreen)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "configuraciones"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "configuraciones"
        Me.layouTopScreen.ResumeLayout(False)
        Me.layouTopScreen.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgTopScreen, System.ComponentModel.ISupportInitialize).EndInit()
        Me.layoutMC.ResumeLayout(False)
        Me.layoutMC.PerformLayout()
        Me.btnCloseOpc.ResumeLayout(False)
        Me.btnCloseOpc.PerformLayout()
        CType(Me.imgBtnCloseOpc, System.ComponentModel.ISupportInitialize).EndInit()
        Me.btnTheme.ResumeLayout(False)
        Me.btnTheme.PerformLayout()
        CType(Me.imgBtnTheme, System.ComponentModel.ISupportInitialize).EndInit()
        Me.btnServers.ResumeLayout(False)
        Me.btnServers.PerformLayout()
        CType(Me.imgBtnServers, System.ComponentModel.ISupportInitialize).EndInit()
        Me.btnGeneral.ResumeLayout(False)
        Me.btnGeneral.PerformLayout()
        CType(Me.imgBtnGeneral, System.ComponentModel.ISupportInitialize).EndInit()
        Me.layoutServers.ResumeLayout(False)
        Me.layoutServers.PerformLayout()
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.btnApply.ResumeLayout(False)
        Me.btnApply.PerformLayout()
        CType(Me.imgBtnApply, System.ComponentModel.ISupportInitialize).EndInit()
        Me.layoutGeneral.ResumeLayout(False)
        Me.layoutGeneral.PerformLayout()
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        Me.btnApplyS.ResumeLayout(False)
        Me.btnApplyS.PerformLayout()
        CType(Me.imgBtnApplyS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.layoutThemes.ResumeLayout(False)
        Me.layoutThemes.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel14.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents layouTopScreen As Panel
    Friend WithEvents layoutMC As Panel
    Friend WithEvents btnGeneral As Panel
    Friend WithEvents imgBtnGeneral As PictureBox
    Friend WithEvents lblBtnGeneral As Label
    Friend WithEvents styleBtnGeneral As Panel
    Friend WithEvents btnTheme As Panel
    Friend WithEvents imgBtnTheme As PictureBox
    Friend WithEvents lblBtnTheme As Label
    Friend WithEvents styleBtnTheme As Panel
    Friend WithEvents btnServers As Panel
    Friend WithEvents imgBtnServers As PictureBox
    Friend WithEvents lblBtnServers As Label
    Friend WithEvents styleBtnServers As Panel
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents imgTopScreen As PictureBox
    Friend WithEvents lblTopScreen As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents layoutServers As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnApply As Panel
    Friend WithEvents imgBtnApply As PictureBox
    Friend WithEvents lblBtnApply As Label
    Friend WithEvents styleBtnApply As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents rbRemoteServer As RadioButton
    Friend WithEvents rbLocalServer As RadioButton
    Friend WithEvents btnCloseOpc As Panel
    Friend WithEvents imgBtnCloseOpc As PictureBox
    Friend WithEvents lblBtnCloseOpc As Label
    Friend WithEvents styleBtnCloseOpc As Panel
    Friend WithEvents layoutGeneral As Panel
    Friend WithEvents btnApplyS As Panel
    Friend WithEvents imgBtnApplyS As PictureBox
    Friend WithEvents lblBtnApplyS As Label
    Friend WithEvents styleBtnApplyS As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents layoutThemes As Panel
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents HScrollBar3 As HScrollBar
    Friend WithEvents HScrollBar2 As HScrollBar
    Friend WithEvents HScrollBar1 As HScrollBar
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Panel8 As Panel
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label23 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Panel14 As Panel
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Panel16 As Panel
    Friend WithEvents TBoxIP As TextBox
    Friend WithEvents styleTBoxIP As Panel
    Friend WithEvents Panel22 As Panel
    Friend WithEvents TBoxPass As TextBox
    Friend WithEvents styleTBoxPass As Panel
    Friend WithEvents Panel20 As Panel
    Friend WithEvents TBoxUser As TextBox
    Friend WithEvents styleTBoxUser As Panel
    Friend WithEvents Panel18 As Panel
    Friend WithEvents TBoxDB As TextBox
    Friend WithEvents styleTBoxDB As Panel
    Friend WithEvents Panel17 As Panel
    Friend WithEvents TBoxPort As TextBox
    Friend WithEvents styleTBoxPort As Panel
    Friend WithEvents chbDisableEmp As CheckBox
    Friend WithEvents Panel19 As Panel
    Friend WithEvents TBoxAcessPass As TextBox
    Friend WithEvents Panel21 As Panel
    Friend WithEvents Label24 As Label
    Friend WithEvents PictureBox6 As PictureBox
End Class
