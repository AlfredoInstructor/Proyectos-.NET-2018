﻿Public Class TCEFilter
    Private dgvData(0, 0) As String 'Array columna-fila
    Private dgv As DataGridView 'datagridview para filtar datos
    Private clmnCount As Integer 'Cantidad de columnas de datos
    Private rowsCount As Integer 'Cantidad de filas del datagridview
    Private filtercolumns As Integer 'La posicion de la columna donde se filtraran los datos

    'Contructor que inicia los valores de las variales globales.
    Public Sub New(dgv As DataGridView, clmnCount As Integer)
        Me.dgv = dgv
        Me.clmnCount = clmnCount
        rowsCount = dgv.Rows.Count
    End Sub

    Public WriteOnly Property Filas() As Integer
        Set(value As Integer)
            rowsCount = value
        End Set
    End Property

    'La columna que se filtrara el dato
    Public WriteOnly Property FilterColumn() As Integer
        Set(value As Integer)
            filtercolumns = value
        End Set
    End Property

    'Método que establece todos los datos del datagrid en memoria
    Public Sub setArrayData()
        ReDim dgvData(clmnCount, rowsCount)
        For i = 0 To rowsCount - 1
            For c = 0 To clmnCount - 1
                dgvData(c, i) = dgv.Item(c, i).Value
            Next
        Next
    End Sub

    'Método para filtrar los datos, segun el parametro t.
    Public Sub Filter(t As String)
        Dim indexesdgv(rowsCount) As Integer? 'Array con la cantidad total de filas que acepta enteros y valores nulos.
        For dgvArrayIndex = 0 To rowsCount - 1
            If dgvData(filtercolumns, dgvArrayIndex).Contains(t) Then
                indexesdgv(dgvArrayIndex) = dgvArrayIndex
            Else
                indexesdgv(dgvArrayIndex) = Nothing
            End If
        Next

        'Deja limpio el datagrid y agrega los datos filtrados
        dgv.Rows.Clear()
        For i = 0 To rowsCount - 1
            If indexesdgv(i) IsNot Nothing Then
                If clmnCount = 5 Then
                    dgv.Rows.Add(dgvData(0, indexesdgv(i)), dgvData(1, indexesdgv(i)), dgvData(2, indexesdgv(i)), dgvData(3, indexesdgv(i)), dgvData(4, indexesdgv(i)))
                ElseIf clmnCount = 8 Then
                    dgv.Rows.Add(dgvData(0, indexesdgv(i)), dgvData(1, indexesdgv(i)), dgvData(2, indexesdgv(i)), dgvData(3, indexesdgv(i)), dgvData(4, indexesdgv(i)),
                                 dgvData(5, indexesdgv(i)), dgvData(6, indexesdgv(i)), dgvData(7, indexesdgv(i)))
                ElseIf clmnCount = 6 Then
                    dgv.Rows.Add(dgvData(0, indexesdgv(i)), dgvData(1, indexesdgv(i)), dgvData(2, indexesdgv(i)), dgvData(3, indexesdgv(i)), dgvData(4, indexesdgv(i)), dgvData(5, indexesdgv(i)))
                ElseIf clmnCount = 1 Then
                    dgv.Rows.Add(dgvData(0, indexesdgv(i)))
                ElseIf clmnCount = 3 Then
                    dgv.Rows.Add(dgvData(0, indexesdgv(i)), dgvData(1, indexesdgv(i)), dgvData(2, indexesdgv(i)))
                End If
            End If
        Next
    End Sub
End Class
